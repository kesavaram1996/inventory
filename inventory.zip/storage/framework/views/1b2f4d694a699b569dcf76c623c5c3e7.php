<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-group">
                            <label for="first_name">First Name</label>
                            <input type="text" class="form-control" value="<?php echo e(old('first_name')); ?>" id="first_name" name="first_name" >
                            <?php if($errors->has('first_name')): ?>
                                <div class="error"><?php echo e($errors->first('first_name')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="last_name">Last Name</label>
                            <input type="text" class="form-control" value="<?php echo e(old('last_name')); ?>" id="last_name" name="last_name" >
                            <?php if($errors->has('last_name')): ?>
                                <div class="error"><?php echo e($errors->first('last_name')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="dob">DOB</label>
                            <input type="date" class="form-control" value="<?php echo e(old('dob')); ?>" id="dob" name="dob" >
                            <?php if($errors->has('dob')): ?>
                                <div class="error"><?php echo e($errors->first('dob')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" value="<?php echo e(old('email')); ?>" id="email" name="email" >
                            <?php if($errors->has('email')): ?>
                                <div class="error"><?php echo e($errors->first('email')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="mobile">Mobile</label>
                            <input type="number" class="form-control" value="<?php echo e(old('mobile')); ?>" id="mobile" name="mobile" >
                            <?php if($errors->has('mobile')): ?>
                                <div class="error"><?php echo e($errors->first('mobile')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="address">Address</label>
                            <input type="text" class="form-control" value="<?php echo e(old('address')); ?>" id="address" name="address" >
                            <?php if($errors->has('address')): ?>
                                <div class="error"><?php echo e($errors->first('address')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="state">State</label>
                            <input type="text" class="form-control" value="<?php echo e(old('state')); ?>" id="state" name="state" >
                            <?php if($errors->has('state')): ?>
                                <div class="error"><?php echo e($errors->first('state')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="city">City</label>
                            <input type="text" class="form-control" value="<?php echo e(old('city')); ?>" id="city" name="city" >
                            <?php if($errors->has('city')): ?>
                                <div class="error"><?php echo e($errors->first('city')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="pincode">Pincode</label>
                            <input type="number" class="form-control" value="<?php echo e(old('pincode')); ?>" id="pincode" name="pincode" >
                            <?php if($errors->has('pincode')): ?>
                                <div class="error"><?php echo e($errors->first('pincode')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" value="<?php echo e(old('password')); ?>" id="password" name="password" >
                            <?php if($errors->has('password')): ?>
                                <div class="error"><?php echo e($errors->first('password')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm">Confirm Password</label>
                            <input type="password" class="form-control" value="<?php echo e(old('password_confirmation')); ?>" id="password-confirm" name="password_confirmation"  autocomplete="new-password">
                            <?php if($errors->has('password_confirmation')): ?>
                                <div class="error"><?php echo e($errors->first('password_confirmation')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="row mb-0 mt-3 text-center">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\inventory\inventory\resources\views/auth/register.blade.php ENDPATH**/ ?>
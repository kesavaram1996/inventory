

<?php $__env->startSection('content'); ?>
        
                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Admin List</h1>
                        <!-- <a class="btn btn-primary float-end" href="<?php echo e(route('admin.create')); ?>">Add Admin</a> -->
                    </div>

                    <!-- Table -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-7">
                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(session('success')): ?>
                                <p class="text-success"><?php echo e(session('success')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="col-xl-12 col-lg-7">
                            <!-- DataTales Example -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Admins</h6>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                            <thead>
                                                <tr>
                                                    <th>S.NO</th>
                                                    <th>Admin Name</th>
                                                    <th>Admin Email</th>
                                                    <th>Created at</th>
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th>S.NO</th>
                                                    <th>Admin Name</th>
                                                    <th>Admin Email</th>
                                                    <th>Created at</th>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                                <?php if($data['admins']): ?>
                                                    <?php $__currentLoopData = $data['admins']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e(++$key); ?></td>
                                                            <td><?php echo e($admin->first_name.' '.$admin->last_name); ?></td>
                                                            <td><?php echo e($admin->email); ?></td>
                                                            <td><?php echo e($admin->created_at); ?></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="4">No data found</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                      
                    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp 8 new\htdocs\inventory\resources\views/admin/index.blade.php ENDPATH**/ ?>
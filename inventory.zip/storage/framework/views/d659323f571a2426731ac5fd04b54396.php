<?php $__env->startSection('content'); ?>
        
                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                        
                    </div>


                    <div class="row">
                        <div class="col-xl-12 col-lg-7">
                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(session('success')): ?>
                                <p class="text-success"><?php echo e(session('success')); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Card Row -->
                    <div class="row">
                        <?php if(auth()->user()->getrole->name == 'Super Admin'): ?>
                        <!-- Total Admins Card -->
                        <div class="col-xl-6 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Total Admins</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($data['total_admins']); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <!-- Total Inventory Card -->
                        <div class="<?php echo e(auth()->user()->getrole->name == 'Super Admin' ? 'col-xl-6':'col-xl-12'); ?> mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Total Inventory Items</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($data['total_items']); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-box fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    

                    <!-- Table -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-7">
                            <?php if(auth()->user()->getrole->name == 'Super Admin'): ?>
                            <!-- Recent Admins DataTales -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Recent Admins</h6>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                            <thead>
                                                <tr>
                                                    <th>S.NO</th>
                                                    <th>Admin Name</th>
                                                    <th>Admin Email</th>
                                                    <th>Created at</th>
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th>S.NO</th>
                                                    <th>Admin Name</th>
                                                    <th>Admin Email</th>
                                                    <th>Created at</th>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                                <?php if($data['recent_admins']): ?>
                                                    <?php $__currentLoopData = $data['recent_admins']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e(++$key); ?></td>
                                                            <td><?php echo e($admin->first_name.' '.$admin->last_name); ?></td>
                                                            <td><?php echo e($admin->email); ?></td>
                                                            <td><?php echo e($admin->created_at); ?></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="4">No data found</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if(auth()->user()->getrole->name == 'Admin'): ?>
                            <!-- Recent Items DataTales -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Recent Inventory Items</h6>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                            <thead>
                                                <tr>
                                                    <th>S.NO</th>
                                                    <th>Name</th>
                                                    <th>Description</th>
                                                    <th>Quantity</th>
                                                    <th>Price</th>
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th>S.NO</th>
                                                    <th>Name</th>
                                                    <th>Description</th>
                                                    <th>Quantity</th>
                                                    <th>Price</th>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                                <?php if($data['recent_items']): ?>
                                                    <?php $__currentLoopData = $data['recent_items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e(++$key); ?></td>
                                                            <td><?php echo e($item->name); ?></td>
                                                            <td><?php echo e($item->description); ?></td>
                                                            <td><?php echo e($item->quantity_in_stock); ?></td>
                                                            <td><?php echo e($item->price); ?></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="5">No data found</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                      
                    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp 8 new\htdocs\inventory\resources\views/home.blade.php ENDPATH**/ ?>
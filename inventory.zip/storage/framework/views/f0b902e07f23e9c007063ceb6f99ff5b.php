

<?php $__env->startSection('content'); ?>
        
                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Add Inventory</h1>
                        <a href="<?php echo e(route('inventory.index')); ?>" class="btn btn-primary float-end">Back</a>
                    </div>

                    <!-- Table -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-7">
                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(session('success')): ?>
                                <p class="text-success"><?php echo e(session('success')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="col-xl-12 col-lg-7">
                            <!-- DataTales Example -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Add Inventory</h6>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-12">
                                            <form method="POST" action="<?php echo e(route('inventory.store')); ?>">
                                                <?php echo csrf_field(); ?>

                                                <!-- Name -->
                                                <div class="form-group">
                                                    <label for="name">Name</label>
                                                    <input type="text" class="form-control" value="<?php echo e(old('name')); ?>" id="name" name="name" >
                                                    <?php if($errors->has('name')): ?>
                                                        <div class="error-msg"><?php echo e($errors->first('name')); ?></div>
                                                    <?php endif; ?>
                                                </div>

                                                <!-- Description -->
                                                <div class="form-group">
                                                    <label for="description">description</label>
                                                    <input type="text" class="form-control" value="<?php echo e(old('description')); ?>" id="description" name="description" >
                                                    <?php if($errors->has('description')): ?>
                                                        <div class="error-msg"><?php echo e($errors->first('description')); ?></div>
                                                    <?php endif; ?>
                                                </div>

                                                <!-- Quantity -->
                                                <div class="form-group">
                                                    <label for="quantity_in_stock">Quantity in Stock</label>
                                                    <input type="number" class="form-control" value="<?php echo e(old('quantity_in_stock')); ?>" id="quantity_in_stock" name="quantity_in_stock" >
                                                    <?php if($errors->has('quantity_in_stock')): ?>
                                                        <div class="error-msg"><?php echo e($errors->first('quantity_in_stock')); ?></div>
                                                    <?php endif; ?>
                                                </div>

                                                <!-- Price -->
                                                <div class="form-group">
                                                    <label for="price">Price</label>
                                                    <input type="number" class="form-control" value="<?php echo e(old('price')); ?>" id="price" name="price" >
                                                    <?php if($errors->has('price')): ?>
                                                        <div class="error-msg"><?php echo e($errors->first('price')); ?></div>
                                                    <?php endif; ?>
                                                </div>

                                                <div class="form-group text-center">
                                                    <input type="submit" class="btn btn-primary">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                      
                    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\inventory\inventory\resources\views/inventory/create.blade.php ENDPATH**/ ?>